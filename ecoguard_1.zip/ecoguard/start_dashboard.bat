@echo off
chcp 65001 >nul
python -m streamlit run dashboard/app.py
pause
