#!/bin/sh
python3 -m uvicorn ecoguard.main:app --port 8000
