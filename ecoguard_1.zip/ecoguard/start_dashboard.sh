#!/bin/sh
python3 -m streamlit run dashboard/app.py
