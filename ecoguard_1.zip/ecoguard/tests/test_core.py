"""驗收測試：對應規格書 TC-01 ~ TC-04，另加重放、速率限制、IP 白名單、帳本竄改等。
執行：python -m unittest discover -s tests -v
"""
import json
import os
import secrets
import sys
import tempfile
import time
import unittest
import warnings

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ecoguard import config, datagen, db  # noqa: E402

_tmp = tempfile.mkdtemp()
config.DB_PATH = type(config.DB_PATH)(os.path.join(_tmp, "test.db"))
config.MODEL_DIR = type(config.MODEL_DIR)(os.path.join(_tmp, "models"))
config.MODEL_DIR.mkdir(exist_ok=True)

from ecoguard.anomaly import AnomalyEngine  # noqa: E402
from ecoguard.pipeline import Gateway  # noqa: E402
from ecoguard.security import compute_signature  # noqa: E402
from ecoguard.simulate import build_request, normal_payload  # noqa: E402


class GatewayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        db.init_db()
        db.create_supplier("SUP-001", "台中精密金屬", "ak_test_001", "secret_test_001", "*")
        db.create_supplier("SUP-002", "高雄塑膠射出", "ak_test_002", "secret_test_002", "10.0.0.5")
        datagen.train(datagen.generate())
        cls.gw = Gateway(engine=AnomalyEngine())
        cls.s1 = db.get_supplier("SUP-001")
        cls.s2 = db.get_supplier("SUP-002")

    def send(self, headers, body, ip="127.0.0.1"):
        return self.gw.handle(headers, body, ip)

    def test_tc01_valid_request_accepted_and_ledgered(self):
        h, b = build_request(self.s1, normal_payload("SUP-001"))
        status, resp = self.send(h, b)
        self.assertEqual(status, 200, resp)
        self.assertEqual(len(resp["data_hash"]), 64)
        self.assertGreater(resp["ledger_index"], 0)

    def test_tc02_mitm_tamper_rejected(self):
        h, b = build_request(self.s1, normal_payload("SUP-001"))
        d = json.loads(b); d["Scope3_Emissions_kgCO2e"] *= 0.5
        status, resp = self.send(h, json.dumps(d).encode())
        self.assertEqual(status, 401)
        self.assertEqual(resp["event"], "BAD_SIGNATURE")

    def test_tc03_fake_data_blocked_by_ai(self):
        p = {"supplier_id": "SUP-001", "period": "2026-10", "Activity_Volume": 1000,
             "Electricity_kWh": 3200, "Scope3_Emissions_kgCO2e": 0.01}
        status, resp = self.send(*build_request(self.s1, p))
        self.assertEqual(status, 422, resp)
        self.assertGreater(resp["anomaly_score"], 0.75)

    def test_tc04_verifier_detects_match_and_tamper(self):
        p = normal_payload("SUP-001")
        status, resp = self.send(*build_request(self.s1, p))
        self.assertEqual(status, 200)
        ok = self.gw.ledger.verify_document(json.dumps(p))
        self.assertEqual(ok["verdict"], "MATCH")
        # 數字寫成 int / float、欄位順序不同，結果也要一致
        reordered = dict(reversed(list(p.items())))
        self.assertEqual(self.gw.ledger.verify_document(json.dumps(reordered))["verdict"], "MATCH")
        # 竄改任何一個數字 → 不一致
        p2 = dict(p); p2["Scope3_Emissions_kgCO2e"] += 1
        self.assertEqual(self.gw.ledger.verify_document(json.dumps(p2))["verdict"], "MISMATCH")

    def test_quarantined_data_is_not_verifiable(self):
        p = {"supplier_id": "SUP-001", "period": "2026-10", "Activity_Volume": 1000,
             "Electricity_kWh": 3200, "Scope3_Emissions_kgCO2e": 0.01}
        self.send(*build_request(self.s1, p))
        self.assertEqual(self.gw.ledger.verify_document(json.dumps(p))["verdict"], "MISMATCH")

    def test_invalid_api_key(self):
        h, b = build_request(self.s1, normal_payload("SUP-001"), api_key="ak_nope")
        self.assertEqual(self.send(h, b)[0], 401)

    def test_replay_attack_blocked(self):
        h, b = build_request(self.s1, normal_payload("SUP-001"))
        self.assertEqual(self.send(h, b)[0], 200)
        status, resp = self.send(h, b)
        self.assertEqual((status, resp["event"]), (401, "REPLAY_ATTACK"))

    def test_stale_timestamp_blocked(self):
        h, b = build_request(self.s1, normal_payload("SUP-001"), ts=time.time() - 60)
        status, resp = self.send(h, b)
        self.assertEqual((status, resp["event"]), (401, "STALE_TIMESTAMP"))

    def test_ip_whitelist(self):
        h, b = build_request(self.s2, normal_payload("SUP-002"))
        self.assertEqual(self.send(h, b, ip="6.6.6.6")[0], 403)
        h, b = build_request(self.s2, normal_payload("SUP-002"))
        self.assertEqual(self.send(h, b, ip="10.0.0.5")[0], 200)

    def test_rate_limit(self):
        db.create_supplier("SUP-009", "壓測供應商", "ak_rate", "secret_rate", "*")
        s = db.get_supplier("SUP-009")
        codes = []
        for _ in range(65):
            p = normal_payload("SUP-001"); p["supplier_id"] = "SUP-009"
            codes.append(self.send(*build_request(s, p))[0])
        self.assertIn(429, codes)
        self.assertEqual(codes[:60].count(429), 0)

    def test_payload_injection_rejected(self):
        p = normal_payload("SUP-001"); p["__proto__"] = {"x": 1}
        self.assertEqual(self.send(*build_request(self.s1, p))[0], 400)
        p = normal_payload("SUP-001"); p["Scope3_Emissions_kgCO2e"] = "1; DROP TABLE"
        self.assertEqual(self.send(*build_request(self.s1, p))[0], 400)
        p = normal_payload("SUP-001"); p["Activity_Volume"] = -5
        self.assertEqual(self.send(*build_request(self.s1, p))[0], 400)
        h, b = build_request(self.s1, normal_payload("SUP-001"))
        self.assertEqual(self.send(h, b"not json")[0], 401)  # 簽章對不上先擋

    def test_supplier_cannot_impersonate_another(self):
        p = normal_payload("SUP-002")  # 用 SUP-001 的金鑰送 SUP-002 的資料
        self.assertEqual(self.send(*build_request(self.s1, p))[0], 403)

    def test_ledger_tamper_detected(self):
        from contextlib import closing
        self.send(*build_request(self.s1, normal_payload("SUP-001")))
        self.assertTrue(self.gw.ledger.verify_chain()[0])
        with closing(db.connect()) as conn:
            idx, orig = conn.execute("SELECT idx, data_hash FROM ledger ORDER BY idx LIMIT 1").fetchone()
            conn.execute("UPDATE ledger SET data_hash='deadbeef' WHERE idx=?", (idx,))  # 模擬有人直接改資料庫
            conn.commit()
        try:
            self.assertFalse(self.gw.ledger.verify_chain()[0])
        finally:  # 還原，避免影響其他測試
            with closing(db.connect()) as conn:
                conn.execute("UPDATE ledger SET data_hash=? WHERE idx=?", (orig, idx))
                conn.commit()
        self.assertTrue(self.gw.ledger.verify_chain()[0])

    def test_normal_traffic_false_positive_rate(self):
        eng = self.gw.engine
        r = datagen.evaluate(eng, n_per_supplier=60)
        self.assertLess(r["false_positive_rate"], 0.05)
        self.assertGreater(r["recall"], 0.70)


if __name__ == "__main__":
    unittest.main(verbosity=2)
