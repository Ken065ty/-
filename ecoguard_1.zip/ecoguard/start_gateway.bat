@echo off
chcp 65001 >nul
python -m uvicorn ecoguard.main:app --port 8000
pause
