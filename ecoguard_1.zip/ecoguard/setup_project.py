"""一鍵初始化：建資料庫 → 建 5 家模擬供應商 → 產生 1,000 筆歷史數據 → 訓練 AI → 顯示攔截率。
只需要執行一次：python setup_project.py
"""
import secrets
import warnings

warnings.filterwarnings("ignore")

from ecoguard import config, datagen, db
from ecoguard.anomaly import AnomalyEngine

print("① 建立資料庫與供應商 ...")
db.init_db()
for sid, p in datagen.SUPPLIER_PROFILES.items():
    if not db.get_supplier(sid):
        db.create_supplier(sid, p["name"], "ak_" + secrets.token_hex(8), secrets.token_hex(24), "*")
datagen.save_profiles()

print("② 產生 1,000 筆模擬碳盤查歷史數據（含 5% 異常）...")
df = datagen.generate()
df.to_csv(config.DATA_DIR / "history.csv", index=False, encoding="utf-8-sig")

print("③ 訓練 AI 異常偵測模型 ...")
datagen.train(df)

print("④ 用全新資料驗證 AI 攔截準確率 ...")
r = datagen.evaluate(AnomalyEngine())
print(f"   攔截率（Recall）  : {r['recall']:.1%}  （{r['TP']}/{r['TP'] + r['FN']} 筆造假被攔下）")
print(f"   誤殺率            : {r['false_positive_rate']:.1%}  （{r['FP']}/{r['FP'] + r['TN']} 筆正常資料被誤判）")
print("\n✅ 初始化完成！接著請啟動閘道與儀表板（見 README.md）。")
