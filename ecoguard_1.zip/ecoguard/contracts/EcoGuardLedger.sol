// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title EcoGuardLedger — 碳數據雜湊存證（只存雜湊，不存原始數據）
contract EcoGuardLedger {
    struct Record {
        bool exists;
        string supplierId;
        uint256 timestamp;
        string aiStatus;
    }

    address public owner;
    mapping(bytes32 => Record) private records;

    event HashStored(bytes32 indexed dataHash, string supplierId, uint256 timestamp, string aiStatus);

    constructor() { owner = msg.sender; }

    function storeHash(bytes32 dataHash, string calldata supplierId, uint256 timestamp, string calldata aiStatus) external {
        require(msg.sender == owner, "only gateway");
        require(!records[dataHash].exists, "already stored"); // 已存證者不可覆寫
        records[dataHash] = Record(true, supplierId, timestamp, aiStatus);
        emit HashStored(dataHash, supplierId, timestamp, aiStatus);
    }

    function verifyHash(bytes32 dataHash) external view returns (bool exists, string memory supplierId, uint256 timestamp, string memory aiStatus) {
        Record storage r = records[dataHash];
        return (r.exists, r.supplierId, r.timestamp, r.aiStatus);
    }
}
