"""模組四：EcoGuard 戰情室（Streamlit）。啟動：streamlit run dashboard/app.py"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import streamlit as st

from ecoguard import config, db, simulate
from ecoguard.ledger import Ledger

st.set_page_config(page_title="EcoGuard AI 戰情室", page_icon="🛡️", layout="wide")
db.init_db()
ledger = Ledger()

st.title("🛡️ EcoGuard AI（綠鏈智安）戰情室")
st.caption(f"零信任綠色供應鏈數據安全閘道　|　帳本模式：{ledger.mode}")

tab1, tab2, tab3, tab4 = st.tabs(["📊 戰情總覽", "📜 即時日誌", "🔍 驗證驗算器", "⚔️ 攻擊模擬 Demo"])


@st.fragment(run_every=3)
def overview():
    s = db.today_stats()
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("本日接收總筆數", s["total"])
    c2.metric("成功寫入", s["success"])
    c3.metric("🚨 攔截異常／攻擊", s["intercepted"], help="AI 異常 + 驗證失敗 + 限流等")
    c4.metric("其中 AI 判定造假", s["anomaly"])
    left, right = st.columns(2)
    with left:
        st.subheader("事件類型分布（今日）")
        if s["by_event"]:
            st.bar_chart(pd.Series(s["by_event"], name="次數"))
        else:
            st.info("今天還沒有資料，到「攻擊模擬 Demo」分頁按按鈕試試。")
    with right:
        st.subheader("AI 異常分數（紅線 = 0.75 門檻）")
        sc = db.recent_scores()
        if sc:
            df = pd.DataFrame(sc)
            df["門檻"] = config.ANOMALY_THRESHOLD
            st.line_chart(df.set_index("ts_text")[["anomaly_score", "門檻"]], color=["#1f77b4", "#d62728"])
    st.subheader("供應商健康度評分")
    st.dataframe(pd.DataFrame(db.supplier_health()).rename(columns={
        "supplier_id": "編號", "name": "供應商", "recent_requests": "近期請求數", "health_score": "健康度"}),
        hide_index=True, use_container_width=True,
        column_config={"健康度": st.column_config.ProgressColumn(min_value=0, max_value=100, format="%.0f")})
    chain_ok, broken = ledger.verify_chain()
    st.success("🔗 帳本雜湊鏈完整，未被竄改") if chain_ok else st.error(f"🔗 帳本在第 {broken} 筆斷裂，疑似被竄改！")


@st.fragment(run_every=3)
def live_log():
    logs = db.recent_logs(100)
    if not logs:
        st.info("尚無日誌")
        return
    df = pd.DataFrame(logs).rename(columns={
        "ts_text": "時間", "supplier_id": "供應商", "client_ip": "來源 IP", "status_code": "狀態碼",
        "event": "事件", "detail": "說明", "anomaly_score": "異常分數"})

    def color(row):
        c = {200: "#e6f4ea", 422: "#fdecea"}.get(row["狀態碼"], "#fff4e5")
        return [f"background-color: {c}; color: #222"] * len(row)

    st.dataframe(df.style.apply(color, axis=1), hide_index=True, use_container_width=True, height=520)
    st.caption("🟢 200 OK　🔴 422 AI 判定異常　🟠 401/403/429 驗證失敗或限流")


with tab1:
    overview()
with tab2:
    live_log()

with tab3:
    st.subheader("稽核驗算器")
    st.write("貼上供應商當初傳送的原始 JSON，系統會重新計算 SHA-256 並與帳本比對。")
    sample = ""
    with st.expander("需要範例？按這裡取最近一筆通過驗證的資料"):
        from contextlib import closing
        with closing(db.connect()) as conn:
            row = conn.execute("SELECT payload_json FROM carbon_data WHERE status='ACCEPTED' ORDER BY id DESC LIMIT 1").fetchone()
        if row:
            st.code(row["payload_json"], language="json")
            st.caption("可複製貼到下方；改動任何一個數字再驗證，就會顯示「曾遭竄改」。")
        else:
            st.write("目前沒有資料。")
    raw = st.text_area("原始碳數據 JSON", height=180, placeholder='{"supplier_id": "SUP-001", ...}')
    if st.button("驗證", type="primary") and raw.strip():
        res = ledger.verify_document(raw)
        (st.success if res["ok"] else st.error)(res["message"])
        if res.get("data_hash"):
            st.code(f"SHA-256: {res['data_hash']}")
        if res.get("ledger_index"):
            st.write(f"帳本編號：#{res['ledger_index']}　供應商：{res['supplier_id']}")
            if res.get("tx_hash"):
                st.write(f"Polygon 交易：{res['tx_hash']}")

with tab4:
    st.subheader("一鍵模擬攻擊")
    st.caption(f"需先啟動閘道（{config.GATEWAY_URL}）。動作會即時反映在上面兩個分頁。")
    sups = db.list_suppliers()
    if not sups:
        st.warning("請先執行 python setup_project.py")
    else:
        sid = st.selectbox("使用哪家供應商的金鑰", [s["supplier_id"] for s in sups],
                           format_func=lambda x: f"{x} {db.get_supplier(x)['name']}")
        sup = db.get_supplier(sid)
        buttons = [("✅ 傳送正常數據", simulate.send_normal), ("🕵️ 中間人竄改 (MITM)", simulate.send_mitm),
                   ("🔑 無效 API Key", simulate.send_invalid_key), ("✍️ 偽造簽章", simulate.send_forged_signature),
                   ("🤥 數據造假（碳排壓到 0.01kg）", simulate.send_anomaly), ("⏰ 過期時間戳", simulate.send_stale)]
        cols = st.columns(3)
        for i, (label, fn) in enumerate(buttons):
            if cols[i % 3].button(label, use_container_width=True):
                try:
                    code, body = fn(sup)
                    (st.success if code == 200 else st.warning)(f"HTTP {code}")
                    st.json(body)
                except Exception as e:
                    st.error(f"連不到閘道：{e}　請確認已啟動 uvicorn。")
        if cols[0].button("🔁 重放攻擊", use_container_width=True):
            try:
                (code, body), _ = simulate.send_replay(sup)
                st.warning(f"第二次送出 → HTTP {code}"); st.json(body)
            except Exception as e:
                st.error(f"連不到閘道：{e}")
        if cols[1].button("🌊 流量爆衝 (70 次)", use_container_width=True):
            try:
                codes = simulate.send_burst(sup)
                st.warning(f"200 × {codes.count(200)}，429 × {codes.count(429)}")
            except Exception as e:
                st.error(f"連不到閘道：{e}")
