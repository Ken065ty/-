"""模組一：零信任傳輸與身份驗證（純 Python，不依賴 Web 框架）。

檢查順序（任何一關失敗就阻斷並記錄）：
  API Key → IP 白名單 → 速率限制 → 時間戳 → HMAC 簽章 → 重放攻擊
"""
import hashlib
import hmac
import threading
import time
from collections import deque

from . import config, db


class SecurityError(Exception):
    def __init__(self, status, event, detail, supplier_id=None):
        super().__init__(detail)
        self.status = status
        self.event = event
        self.detail = detail
        self.supplier_id = supplier_id


def compute_signature(secret_key: str, payload: bytes, timestamp: str) -> str:
    """Signature = HMAC-SHA256(SecretKey, Payload + Timestamp)"""
    return hmac.new(secret_key.encode(), payload + str(timestamp).encode(), hashlib.sha256).hexdigest()


class RateLimiter:
    """滑動視窗：每個 key 在 window 秒內最多 limit 次。"""

    def __init__(self, limit=None, window=60):
        self.limit = limit or config.RATE_LIMIT_PER_MIN
        self.window = window
        self._hits = {}
        self._lock = threading.Lock()

    def allow(self, key, now=None):
        now = now if now is not None else time.time()
        with self._lock:
            q = self._hits.setdefault(key, deque())
            while q and q[0] <= now - self.window:
                q.popleft()
            if len(q) >= self.limit:
                return False
            q.append(now)
            return True


class ReplayCache:
    """記住時間窗內用過的簽章，同一個簽章第二次出現 = 重放攻擊。"""

    def __init__(self, ttl=None):
        self.ttl = ttl or (config.TIMESTAMP_TOLERANCE_SEC * 2 + 5)
        self._seen = {}
        self._lock = threading.Lock()

    def check_and_add(self, signature, now=None):
        now = now if now is not None else time.time()
        with self._lock:
            for s in [s for s, exp in self._seen.items() if exp <= now]:
                del self._seen[s]
            if signature in self._seen:
                return False
            self._seen[signature] = now + self.ttl
            return True


def _ip_allowed(whitelist: str, ip: str) -> bool:
    entries = [e.strip() for e in (whitelist or "*").split(",") if e.strip()]
    return "*" in entries or ip in entries


def authenticate(headers: dict, body: bytes, client_ip: str, limiter: RateLimiter,
                 replay: ReplayCache, now=None) -> dict:
    """驗證通過回傳供應商資料；失敗丟出 SecurityError。"""
    now = now if now is not None else time.time()
    h = {k.lower(): v for k, v in headers.items()}
    api_key = h.get("x-api-key", "")
    signature = h.get("x-signature", "")
    ts_raw = h.get("x-timestamp", "")

    supplier = db.get_supplier_by_key(api_key) if api_key else None

    # 速率限制：已知金鑰以金鑰計；未知金鑰以來源 IP 計（避免攻擊者換金鑰逃過限制）
    rl_key = f"key:{api_key}" if supplier else f"ip:{client_ip}"
    if not limiter.allow(rl_key, now):
        raise SecurityError(429, "RATE_LIMITED", f"超過速率限制（{limiter.limit} 次/分鐘）",
                            supplier["supplier_id"] if supplier else None)

    if not supplier:
        raise SecurityError(401, "INVALID_API_KEY", "API Key 不存在或未提供")
    sid = supplier["supplier_id"]

    if not _ip_allowed(supplier["ip_whitelist"], client_ip):
        raise SecurityError(403, "IP_BLOCKED", f"來源 IP {client_ip} 不在白名單", sid)

    try:
        ts = float(ts_raw)
    except (TypeError, ValueError):
        raise SecurityError(401, "BAD_TIMESTAMP", "缺少或無效的 X-Timestamp", sid)
    if abs(now - ts) > config.TIMESTAMP_TOLERANCE_SEC:
        raise SecurityError(401, "STALE_TIMESTAMP",
                            f"時間戳偏差 {abs(now - ts):.0f} 秒，超過 ±{config.TIMESTAMP_TOLERANCE_SEC} 秒", sid)

    expected = compute_signature(supplier["secret_key"], body, ts_raw)
    if not signature or not hmac.compare_digest(expected, signature):
        raise SecurityError(401, "BAD_SIGNATURE", "簽章比對失敗（資料可能遭竄改）", sid)

    if not replay.check_and_add(signature, now):
        raise SecurityError(401, "REPLAY_ATTACK", "偵測到重複使用的簽章（重放攻擊）", sid)

    return supplier
