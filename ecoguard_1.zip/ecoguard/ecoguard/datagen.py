"""產生模擬製造業碳盤查歷史數據（含 5% 異常篡改）並訓練模型。"""
import json
import math
import random

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest

from . import config
from .anomaly import FEATURES, to_features

# 每家供應商的「正常營運特徵」：(產量中位數, 度/件, kgCO2e/件)
SUPPLIER_PROFILES = {
    "SUP-001": {"name": "台中精密金屬", "activity": 1200, "kwh_per_unit": 3.2, "ef": 0.85},
    "SUP-002": {"name": "高雄塑膠射出", "activity": 5000, "kwh_per_unit": 0.9, "ef": 0.32},
    "SUP-003": {"name": "新竹電子組裝", "activity": 800,  "kwh_per_unit": 5.5, "ef": 1.40},
    "SUP-004": {"name": "台南紡織印染", "activity": 3000, "kwh_per_unit": 1.8, "ef": 0.60},
    "SUP-005": {"name": "桃園包裝材料", "activity": 8000, "kwh_per_unit": 0.5, "ef": 0.18},
}


def _normal(p, rng):
    act = max(10.0, rng.gauss(p["activity"], p["activity"] * 0.12))
    kwh = act * p["kwh_per_unit"] * rng.gauss(1, 0.05)
    em = act * p["ef"] * rng.gauss(1, 0.05)
    return {"Activity_Volume": round(act, 1), "Electricity_kWh": round(kwh, 1),
            "Scope3_Emissions_kgCO2e": round(em, 2)}


def _tamper(rec, rng):
    """模擬幾種常見的造假手法。"""
    r = dict(rec)
    kind = rng.choice(["under_report", "under_report", "spike", "elec_mismatch"])
    if kind == "under_report":        # 把碳排壓到 1%~25%
        r["Scope3_Emissions_kgCO2e"] = round(rec["Scope3_Emissions_kgCO2e"] * rng.uniform(0.005, 0.25), 3)
    elif kind == "spike":             # 數值爆衝
        r["Scope3_Emissions_kgCO2e"] = round(rec["Scope3_Emissions_kgCO2e"] * rng.uniform(4, 30), 2)
    else:                             # 用電量與產量對不起來
        r["Electricity_kWh"] = round(rec["Electricity_kWh"] * rng.choice([rng.uniform(0.02, 0.2), rng.uniform(5, 20)]), 1)
    return r


def generate(n_per_supplier=200, anomaly_rate=0.05, seed=42):
    rng = random.Random(seed)
    rows = []
    for sid, p in SUPPLIER_PROFILES.items():
        for _ in range(n_per_supplier):
            rec = _normal(p, rng)
            is_anom = rng.random() < anomaly_rate
            if is_anom:
                rec = _tamper(rec, rng)
            rec.update(supplier_id=sid, is_anomaly=int(is_anom))
            rec["Emission_Factor_Ratio"] = rec["Scope3_Emissions_kgCO2e"] / rec["Activity_Volume"]
            rows.append(rec)
    return pd.DataFrame(rows)


def train(df, contamination=0.05, seed=42):
    """每家供應商訓練一個 Isolation Forest，另訓練一個 _global 當備援。"""
    config.MODEL_DIR.mkdir(exist_ok=True)
    groups = {sid: g for sid, g in df.groupby("supplier_id")}
    groups["_global"] = df
    for name, g in groups.items():
        X = np.vstack([to_features(r) for r in g.to_dict("records")])
        model = IsolationForest(n_estimators=200, contamination=contamination, random_state=seed).fit(X)
        # boundary = 模型在 contamination 比例處的決策邊界（原始分數），供分數校準使用
        joblib.dump({"model": model, "boundary": float(-model.offset_)}, config.MODEL_DIR / f"{name}.joblib")


def evaluate(engine, seed=2026, n_per_supplier=100):
    """用全新的資料（沒給模型看過）測攔截準確率。"""
    df = generate(n_per_supplier=n_per_supplier, anomaly_rate=0.10, seed=seed)
    tp = fp = tn = fn = 0
    for r in df.to_dict("records"):
        s = engine.score(r["supplier_id"], r)
        pred = engine.is_anomaly(s)
        if r["is_anomaly"] and pred: tp += 1
        elif r["is_anomaly"]: fn += 1
        elif pred: fp += 1
        else: tn += 1
    return {"TP": tp, "FN": fn, "FP": fp, "TN": tn,
            "recall": tp / max(1, tp + fn), "precision": tp / max(1, tp + fp),
            "false_positive_rate": fp / max(1, fp + tn)}


def save_profiles():
    (config.DATA_DIR / "profiles.json").write_text(
        json.dumps(SUPPLIER_PROFILES, ensure_ascii=False, indent=2), encoding="utf-8")
