"""攻擊 / 正常流量模擬器（Demo 用）。
可從儀表板按鈕呼叫，也可用命令列：python -m ecoguard.simulate
"""
import json
import random
import time

import requests

from . import config, db
from .security import compute_signature
from .datagen import SUPPLIER_PROFILES


def normal_payload(supplier_id, rng=random):
    p = SUPPLIER_PROFILES[supplier_id]
    act = max(10.0, rng.gauss(p["activity"], p["activity"] * 0.08))
    return {"supplier_id": supplier_id, "period": time.strftime("%Y-%m"),
            "Activity_Volume": round(act, 1),
            "Electricity_kWh": round(act * p["kwh_per_unit"] * rng.gauss(1, 0.03), 1),
            "Scope3_Emissions_kgCO2e": round(act * p["ef"] * rng.gauss(1, 0.03), 2)}


def build_request(supplier, payload, ts=None, api_key=None, secret=None):
    """依規格組出簽章過的請求：回傳 (headers, body_bytes)。"""
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    ts = str(int(ts if ts is not None else time.time()))
    sig = compute_signature(secret or supplier["secret_key"], body, ts)
    headers = {"Content-Type": "application/json", "X-API-KEY": api_key or supplier["api_key"],
               "X-Timestamp": ts, "X-Signature": sig}
    return headers, body


def _post(headers, body, url=None):
    r = requests.post((url or config.GATEWAY_URL) + "/api/v1/carbon-data", data=body, headers=headers, timeout=15)
    try:
        return r.status_code, r.json()
    except Exception:
        return r.status_code, {"raw": r.text}


# ---- 各種情境（回傳 (狀態碼, 回應)）----
def send_normal(supplier):
    return _post(*build_request(supplier, normal_payload(supplier["supplier_id"])))


def send_mitm(supplier):
    """中間人攻擊：簽章是對原始資料算的，但傳輸途中碳排被改小。"""
    payload = normal_payload(supplier["supplier_id"])
    headers, body = build_request(supplier, payload)
    tampered = json.loads(body)
    tampered["Scope3_Emissions_kgCO2e"] = round(tampered["Scope3_Emissions_kgCO2e"] * 0.5, 2)
    return _post(headers, json.dumps(tampered).encode())


def send_invalid_key(supplier):
    return _post(*build_request(supplier, normal_payload(supplier["supplier_id"]), api_key="ak_fake_0000000000000000"))


def send_forged_signature(supplier):
    """知道有效 API Key 但沒有 Secret Key。"""
    return _post(*build_request(supplier, normal_payload(supplier["supplier_id"]), secret="wrong-secret"))


def send_anomaly(supplier):
    """簽章合法，但數據造假：產量 1000 件、碳排只報 0.01kg。"""
    payload = {"supplier_id": supplier["supplier_id"], "period": time.strftime("%Y-%m"),
               "Activity_Volume": 1000.0, "Electricity_kWh": 3200.0, "Scope3_Emissions_kgCO2e": 0.01}
    return _post(*build_request(supplier, payload))


def send_replay(supplier):
    """重放攻擊：把一份合法請求原封不動送兩次，第二次應被擋。"""
    headers, body = build_request(supplier, normal_payload(supplier["supplier_id"]))
    first = _post(headers, body)
    second = _post(headers, body)
    return second, first


def send_stale(supplier):
    return _post(*build_request(supplier, normal_payload(supplier["supplier_id"]), ts=time.time() - 120))


def send_burst(supplier, n=70):
    """流量攻擊：短時間狂送 n 次，超過 60 次/分鐘後應回 429。"""
    codes = []
    for _ in range(n):
        codes.append(_post(*build_request(supplier, normal_payload(supplier["supplier_id"])))[0])
    return codes


SCENARIOS = [
    ("正常數據", send_normal, 200),
    ("中間人竄改 (MITM)", send_mitm, 401),
    ("無效 API Key", send_invalid_key, 401),
    ("偽造簽章", send_forged_signature, 401),
    ("數據造假 (AI 攔截)", send_anomaly, 422),
    ("過期時間戳", send_stale, 401),
]


def run_all(supplier_id="SUP-001"):
    supplier = db.get_supplier(supplier_id)
    if not supplier:
        raise SystemExit("找不到供應商，請先執行 python setup_project.py")
    print(f"{'情境':<22}{'預期':<8}{'實際':<8}結果")
    ok_all = True
    for name, fn, expect in SCENARIOS:
        status, _ = fn(supplier)
        ok = status == expect
        ok_all &= ok
        print(f"{name:<20}{expect:<8}{status:<8}{'✅ 通過' if ok else '❌ 不符'}")
    (status, _), _ = send_replay(supplier)
    ok = status == 401; ok_all &= ok
    print(f"{'重放攻擊':<20}{401:<8}{status:<8}{'✅ 通過' if ok else '❌ 不符'}")
    codes = send_burst(supplier)
    ok = 429 in codes; ok_all &= ok
    print(f"{'流量爆衝(70次)':<19}{'含429':<8}{codes.count(429)}次429  {'✅ 通過' if ok else '❌ 不符'}")
    print("\n全部符合預期 🎉" if ok_all else "\n有項目不符預期，請檢查。")


if __name__ == "__main__":
    run_all()
