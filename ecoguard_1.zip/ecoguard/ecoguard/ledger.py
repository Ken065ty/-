"""模組三：不可篡改雜湊帳本。

預設模式（本機雜湊鏈）：每筆紀錄都包含「上一筆的雜湊」，任何一筆被改，後面整條鏈都對不上
  —— 與 ImmuDB 的防篡改概念相同，不需要任何帳號或網路。
進階模式（Polygon Amoy 測試網）：設定三個環境變數後，通過的資料雜湊會再寫一份上鏈。
鏈上只存 Supplier_ID + Timestamp + Data_SHA256_Hash + AI_Verify_Status，不存原始數據。
"""
import hashlib
import json
import threading
import time
from contextlib import closing

from . import config, db

GENESIS = "0" * 64
_lock = threading.Lock()


def canonical_hash(payload: dict) -> str:
    """把資料標準化（欄位排序、數字統一為 float）後算 SHA-256，讓稽核員重算結果一致。"""
    norm = {k: (float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else v)
            for k, v in payload.items()}
    blob = json.dumps(norm, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def _entry_hash(prev_hash, ts, supplier_id, data_hash, ai_status):
    raw = f"{prev_hash}|{ts!r}|{supplier_id}|{data_hash}|{ai_status}"
    return hashlib.sha256(raw.encode()).hexdigest()


class PolygonClient:
    """選用：把雜湊寫到 Polygon Amoy。未設定環境變數時 enabled=False。"""

    ABI = [
        {"name": "storeHash", "type": "function", "stateMutability": "nonpayable", "outputs": [],
         "inputs": [{"name": "dataHash", "type": "bytes32"}, {"name": "supplierId", "type": "string"},
                    {"name": "timestamp", "type": "uint256"}, {"name": "aiStatus", "type": "string"}]},
        {"name": "verifyHash", "type": "function", "stateMutability": "view",
         "inputs": [{"name": "dataHash", "type": "bytes32"}],
         "outputs": [{"name": "exists", "type": "bool"}, {"name": "supplierId", "type": "string"},
                     {"name": "timestamp", "type": "uint256"}, {"name": "aiStatus", "type": "string"}]},
    ]

    def __init__(self):
        self.enabled = bool(config.POLYGON_RPC_URL and config.POLYGON_PRIVATE_KEY and config.POLYGON_CONTRACT_ADDRESS)
        self.w3 = self.contract = self.account = None
        if self.enabled:
            try:
                from web3 import Web3
                self.w3 = Web3(Web3.HTTPProvider(config.POLYGON_RPC_URL, request_kwargs={"timeout": 20}))
                self.account = self.w3.eth.account.from_key(config.POLYGON_PRIVATE_KEY)
                self.contract = self.w3.eth.contract(
                    address=Web3.to_checksum_address(config.POLYGON_CONTRACT_ADDRESS), abi=self.ABI)
            except Exception as e:  # 缺套件或設定錯誤 → 自動退回本機模式
                print(f"[EcoGuard] Polygon 初始化失敗，改用本機帳本：{e}")
                self.enabled = False

    def store(self, data_hash, supplier_id, ts, ai_status):
        tx = self.contract.functions.storeHash(
            bytes.fromhex(data_hash), supplier_id, int(ts), ai_status
        ).build_transaction({
            "from": self.account.address,
            "nonce": self.w3.eth.get_transaction_count(self.account.address),
            "gasPrice": self.w3.eth.gas_price,
        })
        signed = self.account.sign_transaction(tx)
        raw = getattr(signed, "raw_transaction", None) or signed.rawTransaction
        h = self.w3.eth.send_raw_transaction(raw).hex()
        return h if h.startswith("0x") else "0x" + h

    def verify(self, data_hash):
        exists, sid, ts, status = self.contract.functions.verifyHash(bytes.fromhex(data_hash)).call()
        return {"exists": exists, "supplier_id": sid, "timestamp": ts, "ai_status": status}


class Ledger:
    def __init__(self):
        self.polygon = PolygonClient()

    @property
    def mode(self):
        return "本機雜湊鏈 + Polygon Amoy" if self.polygon.enabled else "本機雜湊鏈（ImmuDB 概念）"

    def append(self, supplier_id, data_hash, ai_status="PASS"):
        ts = round(time.time(), 3)
        tx_hash = None
        if self.polygon.enabled:
            try:
                tx_hash = self.polygon.store(data_hash, supplier_id, ts, ai_status)
            except Exception as e:
                print(f"[EcoGuard] 上鏈失敗，僅寫入本機帳本：{e}")
        with _lock, closing(db.connect()) as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT entry_hash FROM ledger ORDER BY idx DESC LIMIT 1").fetchone()
            prev = row["entry_hash"] if row else GENESIS
            eh = _entry_hash(prev, ts, supplier_id, data_hash, ai_status)
            cur = conn.execute(
                "INSERT INTO ledger (ts, supplier_id, data_hash, ai_status, prev_hash, entry_hash, tx_hash)"
                " VALUES (?,?,?,?,?,?,?)", (ts, supplier_id, data_hash, ai_status, prev, eh, tx_hash))
            conn.commit()
            return {"index": cur.lastrowid, "entry_hash": eh, "tx_hash": tx_hash}

    def verify_chain(self):
        """檢查整條雜湊鏈是否被動過。回傳 (是否完好, 第一個出問題的 index 或 None)。"""
        with closing(db.connect()) as conn:
            prev = GENESIS
            for r in conn.execute("SELECT * FROM ledger ORDER BY idx"):
                if r["prev_hash"] != prev or r["entry_hash"] != _entry_hash(
                        r["prev_hash"], r["ts"], r["supplier_id"], r["data_hash"], r["ai_status"]):
                    return False, r["idx"]
                prev = r["entry_hash"]
        return True, None

    def lookup(self, data_hash):
        with closing(db.connect()) as conn:
            row = conn.execute("SELECT * FROM ledger WHERE data_hash=? AND ai_status='PASS' ORDER BY idx LIMIT 1",
                               (data_hash,)).fetchone()
        local = dict(row) if row else None
        chain = None
        if self.polygon.enabled:
            try:
                chain = self.polygon.verify(data_hash)
            except Exception as e:
                chain = {"error": str(e)}
        return local, chain

    def verify_document(self, raw_json: str):
        """稽核員驗算器：輸入原始 JSON → 重算 Hash → 比對帳本。"""
        try:
            payload = json.loads(raw_json)
            if not isinstance(payload, dict):
                raise ValueError
        except Exception:
            return {"ok": False, "verdict": "INVALID_INPUT", "message": "輸入內容不是合法的 JSON 物件"}
        h = canonical_hash(payload)
        local, chain = self.lookup(h)
        chain_ok = bool(chain and chain.get("exists"))
        chain_intact, broken_at = self.verify_chain()
        if local and chain_intact and (chain is None or chain_ok):
            return {"ok": True, "verdict": "MATCH", "data_hash": h, "ledger_index": local["idx"],
                    "supplier_id": local["supplier_id"], "tx_hash": local["tx_hash"],
                    "message": "✅ 數據與帳本紀錄一致，未被竄改"
                               + ("（已與 Polygon 鏈上紀錄交叉比對）" if chain_ok else "")}
        if local and not chain_intact:
            return {"ok": False, "verdict": "LEDGER_TAMPERED", "data_hash": h,
                    "message": f"⚠️ 帳本雜湊鏈在第 {broken_at} 筆斷裂，帳本本身可能遭竄改"}
        return {"ok": False, "verdict": "MISMATCH", "data_hash": h,
                "message": "❌ 找不到相符的紀錄：此數據與當初傳輸的版本不同（或從未通過驗證），疑似遭竄改"}
