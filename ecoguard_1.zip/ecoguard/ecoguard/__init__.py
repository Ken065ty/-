"""EcoGuard AI（綠鏈智安）— 零信任綠色供應鏈數據安全閘道 MVP"""
__version__ = "1.0.0"
