"""閘道主流程：把 模組一 → 模組二 → 模組三 串起來（純 Python，方便測試）。"""
from . import config, db
from .anomaly import AnomalyEngine, PayloadError, validate_payload
from .ledger import Ledger, canonical_hash
from .security import RateLimiter, ReplayCache, SecurityError, authenticate


class Gateway:
    def __init__(self, engine=None, ledger=None):
        db.init_db()
        self.limiter = RateLimiter()
        self.replay = ReplayCache()
        self.engine = engine or AnomalyEngine()
        self.ledger = ledger or Ledger()

    def handle(self, headers: dict, body: bytes, client_ip: str = "unknown"):
        """回傳 (HTTP 狀態碼, 回應 dict)。每一種結果都會寫入日誌供戰情室顯示。"""
        # 模組一：零信任
        try:
            supplier = authenticate(headers, body, client_ip, self.limiter, self.replay)
        except SecurityError as e:
            db.log_event(e.status, e.event, e.detail, e.supplier_id, client_ip)
            return e.status, {"status": "rejected", "event": e.event, "detail": e.detail}
        sid = supplier["supplier_id"]

        # 格式檢查（擋格式注入）
        try:
            rec = validate_payload(body)
        except PayloadError as e:
            db.log_event(400, "BAD_PAYLOAD", str(e), sid, client_ip)
            return 400, {"status": "rejected", "event": "BAD_PAYLOAD", "detail": str(e)}
        if rec["supplier_id"] != sid:
            detail = f"Payload 的 supplier_id（{rec['supplier_id']}）與金鑰所屬供應商（{sid}）不符"
            db.log_event(403, "SUPPLIER_MISMATCH", detail, sid, client_ip)
            return 403, {"status": "rejected", "event": "SUPPLIER_MISMATCH", "detail": detail}

        # 模組二：AI 異常偵測
        if not self.engine.ready:
            db.log_event(503, "MODEL_NOT_READY", "AI 模型尚未訓練", sid, client_ip)
            return 503, {"status": "error", "event": "MODEL_NOT_READY", "detail": "AI 模型尚未訓練"}
        score = round(self.engine.score(sid, rec), 4)
        data_hash = canonical_hash(rec)

        if self.engine.is_anomaly(score):
            detail = f"Anomaly Score={score} > {config.ANOMALY_THRESHOLD}，資料隔離、拒絕寫入"
            db.save_carbon_data(sid, rec, data_hash, score, "QUARANTINED")
            db.log_event(422, "ANOMALY", detail, sid, client_ip, score)
            return 422, {"status": "rejected", "event": "ANOMALY", "anomaly_score": score, "detail": detail}

        # 模組三：存證與入庫
        entry = self.ledger.append(sid, data_hash, "PASS")
        db.save_carbon_data(sid, rec, data_hash, score, "ACCEPTED")
        db.log_event(200, "OK", f"通過驗證，已存證（帳本 #{entry['index']}）", sid, client_ip, score)
        return 200, {"status": "accepted", "anomaly_score": score, "data_hash": data_hash,
                     "ledger_index": entry["index"], "tx_hash": entry["tx_hash"],
                     "ledger_mode": self.ledger.mode}
