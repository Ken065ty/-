"""模組二：AI 數據異常偵測（Isolation Forest，每家供應商一個模型）。"""
import json
import math
from pathlib import Path

import joblib
import numpy as np

from . import config

FEATURES = ["Activity_Volume", "Electricity_kWh", "Scope3_Emissions_kgCO2e", "Emission_Factor_Ratio"]
ALLOWED_KEYS = {"supplier_id", "period", *FEATURES[:3]}
REQUIRED_KEYS = {"supplier_id", "period", *FEATURES[:3]}


class PayloadError(Exception):
    pass


def validate_payload(raw: bytes) -> dict:
    """解析並嚴格驗證請求內容（擋格式注入）。回傳標準化後的 dict（數值一律 float）。"""
    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception:
        raise PayloadError("請求內容不是合法的 JSON")
    if not isinstance(data, dict):
        raise PayloadError("JSON 最外層必須是物件")
    extra = set(data) - ALLOWED_KEYS
    if extra:
        raise PayloadError(f"含有不允許的欄位：{sorted(extra)}")
    missing = REQUIRED_KEYS - set(data)
    if missing:
        raise PayloadError(f"缺少必要欄位：{sorted(missing)}")
    if not isinstance(data["supplier_id"], str) or not (0 < len(data["supplier_id"]) <= 32):
        raise PayloadError("supplier_id 格式錯誤")
    if not isinstance(data["period"], str) or not (0 < len(data["period"]) <= 16):
        raise PayloadError("period 格式錯誤（例：2026-10）")
    out = {"supplier_id": data["supplier_id"], "period": data["period"]}
    for k in FEATURES[:3]:
        v = data[k]
        if isinstance(v, bool) or not isinstance(v, (int, float)):
            raise PayloadError(f"{k} 必須是數字")
        v = float(v)
        if not math.isfinite(v) or v < 0 or v > 1e12:
            raise PayloadError(f"{k} 數值超出合理範圍")
        out[k] = v
    if out["Activity_Volume"] <= 0:
        raise PayloadError("Activity_Volume 必須大於 0")
    return out


CALIBRATION_K = 40.0   # 分數校準的陡峭度（見 calibrated_score 說明）


def to_features(rec: dict) -> np.ndarray:
    """規格書 4 個特徵 + 1 個衍生特徵（每件用電量），全部取 log。

    取 log 讓「差 100 倍」在數值上是等距的，孤立森林才抓得準；
    衍生特徵能抓到「用電量與產量對不上」的造假手法（實測可提升攔截率）。
    """
    act, kwh, em = rec["Activity_Volume"], rec["Electricity_kWh"], rec["Scope3_Emissions_kgCO2e"]
    ratio = em / act  # 單位產量碳排比：由伺服器自己算，不信任客戶端
    return np.array([[math.log1p(act), math.log1p(kwh), math.log1p(em),
                      math.log(ratio + 1e-6), math.log(kwh / act + 1e-6)]])


def calibrated_score(raw: float, boundary: float, k: float = CALIBRATION_K) -> float:
    """把孤立森林原始分數轉成 0~1 的「異常分數」。

    為什麼要校準：孤立森林原始分數在小樣本下幾乎不可能超過 0.7，
    直接套用 0.75 門檻等於什麼都攔不到。這裡以模型自己的決策邊界（boundary）為 0.5，
    離邊界越遠分數越接近 1，因此 0.75 代表「明確超出歷史正常範圍」。
    """
    return 1.0 / (1.0 + math.exp(-k * (raw - boundary)))


class AnomalyEngine:
    def __init__(self, model_dir: Path = None):
        self.model_dir = Path(model_dir or config.MODEL_DIR)
        self.models = {}
        self.load()

    def load(self):
        self.models = {}
        for p in self.model_dir.glob("*.joblib"):
            self.models[p.stem] = joblib.load(p)

    @property
    def ready(self):
        return bool(self.models)

    def score(self, supplier_id: str, rec: dict) -> float:
        """回傳 0~1 的異常分數，越高越異常。（sklearn 的 score_samples 取負號即為論文定義的分數）"""
        bundle = self.models.get(supplier_id) or self.models.get("_global")
        if bundle is None:
            raise RuntimeError("AI 模型尚未訓練，請先執行 python setup_project.py")
        raw = float(-bundle["model"].score_samples(to_features(rec))[0])
        return calibrated_score(raw, bundle["boundary"])

    def is_anomaly(self, score: float) -> bool:
        return score > config.ANOMALY_THRESHOLD
