"""集中設定。要調整門檻值、速率限制，改這裡就好。"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
MODEL_DIR = BASE_DIR / "models"
DATA_DIR.mkdir(exist_ok=True)
MODEL_DIR.mkdir(exist_ok=True)

DB_PATH = Path(os.getenv("ECOGUARD_DB", DATA_DIR / "ecoguard.db"))

# --- 模組一：零信任 ---
TIMESTAMP_TOLERANCE_SEC = 30      # 時間戳允許誤差（±秒）
RATE_LIMIT_PER_MIN = 60           # 每個金鑰每分鐘最大請求數

# --- 模組二：AI 異常偵測 ---
ANOMALY_THRESHOLD = 0.75          # 分數 > 此值 → 判定極度異常，拒絕寫入

# --- 模組三：帳本 ---
# 若要真的上 Polygon Amoy 測試網，設定以下三個環境變數即可（詳見 README）
POLYGON_RPC_URL = os.getenv("POLYGON_RPC_URL", "")           # 例：https://rpc-amoy.polygon.technology
POLYGON_PRIVATE_KEY = os.getenv("POLYGON_PRIVATE_KEY", "")   # 測試錢包私鑰（絕對不要用真錢包）
POLYGON_CONTRACT_ADDRESS = os.getenv("POLYGON_CONTRACT_ADDRESS", "")

# --- 模擬器 / 儀表板連線位置 ---
GATEWAY_URL = os.getenv("ECOGUARD_GATEWAY_URL", "http://127.0.0.1:8000")
