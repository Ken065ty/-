"""FastAPI 閘道入口。啟動：uvicorn ecoguard.main:app --port 8000"""
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from starlette.concurrency import run_in_threadpool

from . import __version__, db
from .pipeline import Gateway

app = FastAPI(title="EcoGuard AI 安全閘道器", version=__version__,
              description="零信任 + AI 異常偵測 + 不可篡改帳本。互動式文件：/docs")
gateway = Gateway()


@app.get("/", include_in_schema=False, response_class=HTMLResponse)
def home():
    return ("<h2>🛡️ EcoGuard AI 閘道運作中</h2><p>閘道是給程式呼叫的 API，沒有網頁畫面。</p>"
            "<ul><li><a href='/docs'>API 文件</a></li><li><a href='/api/v1/health'>健康檢查</a></li></ul>"
            "<p>要看戰情室請開 <a href='http://localhost:8501'>http://localhost:8501</a></p>")


@app.post("/api/v1/carbon-data", summary="供應商上傳碳排數據")
async def ingest(request: Request):
    body = await request.body()  # 必須用「原始位元組」驗簽，不能先解析再重組
    ip = request.client.host if request.client else "unknown"
    status, resp = await run_in_threadpool(gateway.handle, dict(request.headers), body, ip)
    return JSONResponse(resp, status_code=status)


@app.post("/api/v1/verify", summary="稽核驗算：貼上原始 JSON，比對帳本")
async def verify(request: Request):
    raw = (await request.body()).decode("utf-8", errors="replace")
    return await run_in_threadpool(gateway.ledger.verify_document, raw)


@app.get("/api/v1/health", summary="健康檢查")
def health():
    chain_ok, _ = gateway.ledger.verify_chain()
    return {"status": "ok", "version": __version__, "model_ready": gateway.engine.ready,
            "ledger_mode": gateway.ledger.mode, "ledger_chain_intact": chain_ok}


@app.get("/api/v1/stats", summary="今日統計")
def stats():
    return db.today_stats()
