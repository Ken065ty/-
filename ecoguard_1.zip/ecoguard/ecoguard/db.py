"""SQLite 資料層（標準函式庫即可，不需額外安裝）。"""
import json
import sqlite3
import time
from contextlib import closing
from datetime import datetime

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS suppliers (
    supplier_id   TEXT PRIMARY KEY,
    name          TEXT NOT NULL,
    api_key       TEXT UNIQUE NOT NULL,
    secret_key    TEXT NOT NULL,
    ip_whitelist  TEXT NOT NULL DEFAULT '*'
);
CREATE TABLE IF NOT EXISTS request_log (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    ts            REAL NOT NULL,
    ts_text       TEXT NOT NULL,
    supplier_id   TEXT,
    client_ip     TEXT,
    status_code   INTEGER NOT NULL,
    event         TEXT NOT NULL,
    detail        TEXT,
    anomaly_score REAL
);
CREATE TABLE IF NOT EXISTS carbon_data (          -- 模擬「中心廠 ESG 資料庫」
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    ts            REAL NOT NULL,
    supplier_id   TEXT NOT NULL,
    payload_json  TEXT NOT NULL,
    data_hash     TEXT NOT NULL,
    anomaly_score REAL,
    status        TEXT NOT NULL              -- ACCEPTED / QUARANTINED
);
CREATE TABLE IF NOT EXISTS ledger (               -- 不可篡改雜湊帳本（雜湊鏈）
    idx           INTEGER PRIMARY KEY AUTOINCREMENT,
    ts            REAL NOT NULL,
    supplier_id   TEXT NOT NULL,
    data_hash     TEXT NOT NULL,
    ai_status     TEXT NOT NULL,
    prev_hash     TEXT NOT NULL,
    entry_hash    TEXT NOT NULL,
    tx_hash       TEXT                        -- 若有上 Polygon，記錄交易編號
);
CREATE INDEX IF NOT EXISTS idx_ledger_hash ON ledger(data_hash);
CREATE INDEX IF NOT EXISTS idx_log_ts ON request_log(ts);
"""


def connect():
    conn = sqlite3.connect(str(config.DB_PATH), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_db():
    with closing(connect()) as conn:
        conn.executescript(SCHEMA)
        conn.commit()


# ---------- 供應商 ----------
def create_supplier(supplier_id, name, api_key, secret_key, ip_whitelist="*"):
    with closing(connect()) as conn:
        conn.execute(
            "INSERT OR REPLACE INTO suppliers VALUES (?,?,?,?,?)",
            (supplier_id, name, api_key, secret_key, ip_whitelist),
        )
        conn.commit()


def get_supplier_by_key(api_key):
    with closing(connect()) as conn:
        row = conn.execute("SELECT * FROM suppliers WHERE api_key=?", (api_key,)).fetchone()
        return dict(row) if row else None


def get_supplier(supplier_id):
    with closing(connect()) as conn:
        row = conn.execute("SELECT * FROM suppliers WHERE supplier_id=?", (supplier_id,)).fetchone()
        return dict(row) if row else None


def list_suppliers():
    with closing(connect()) as conn:
        return [dict(r) for r in conn.execute("SELECT * FROM suppliers ORDER BY supplier_id")]


# ---------- 日誌 ----------
def log_event(status_code, event, detail="", supplier_id=None, client_ip=None, anomaly_score=None):
    now = time.time()
    with closing(connect()) as conn:
        conn.execute(
            "INSERT INTO request_log (ts, ts_text, supplier_id, client_ip, status_code, event, detail, anomaly_score)"
            " VALUES (?,?,?,?,?,?,?,?)",
            (now, datetime.fromtimestamp(now).strftime("%Y-%m-%d %H:%M:%S"),
             supplier_id, client_ip, status_code, event, detail, anomaly_score),
        )
        conn.commit()


def recent_logs(limit=100):
    with closing(connect()) as conn:
        return [dict(r) for r in conn.execute(
            "SELECT ts_text, supplier_id, client_ip, status_code, event, detail, anomaly_score"
            " FROM request_log ORDER BY id DESC LIMIT ?", (limit,))]


def today_stats():
    start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
    with closing(connect()) as conn:
        total = conn.execute("SELECT COUNT(*) FROM request_log WHERE ts>=?", (start,)).fetchone()[0]
        ok = conn.execute("SELECT COUNT(*) FROM request_log WHERE ts>=? AND status_code=200", (start,)).fetchone()[0]
        anomaly = conn.execute("SELECT COUNT(*) FROM request_log WHERE ts>=? AND status_code=422", (start,)).fetchone()[0]
        blocked = conn.execute(
            "SELECT COUNT(*) FROM request_log WHERE ts>=? AND status_code NOT IN (200,422)", (start,)).fetchone()[0]
        by_event = {r[0]: r[1] for r in conn.execute(
            "SELECT event, COUNT(*) FROM request_log WHERE ts>=? GROUP BY event", (start,))}
    return {"total": total, "success": ok, "anomaly": anomaly, "blocked": blocked,
            "intercepted": anomaly + blocked, "by_event": by_event}


def supplier_health(window=50):
    """供應商健康度 = 最近 window 筆請求中成功的比例 × 100。"""
    result = []
    with closing(connect()) as conn:
        for s in conn.execute("SELECT supplier_id, name FROM suppliers ORDER BY supplier_id").fetchall():
            rows = conn.execute(
                "SELECT status_code FROM request_log WHERE supplier_id=? ORDER BY id DESC LIMIT ?",
                (s["supplier_id"], window)).fetchall()
            n = len(rows)
            ok = sum(1 for r in rows if r["status_code"] == 200)
            result.append({"supplier_id": s["supplier_id"], "name": s["name"], "recent_requests": n,
                           "health_score": round(100 * ok / n, 1) if n else None})
    return result


def recent_scores(limit=60):
    with closing(connect()) as conn:
        rows = conn.execute(
            "SELECT ts_text, anomaly_score FROM request_log WHERE anomaly_score IS NOT NULL"
            " ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in reversed(rows)]


# ---------- 中心廠 ESG 資料 ----------
def save_carbon_data(supplier_id, payload, data_hash, anomaly_score, status):
    with closing(connect()) as conn:
        conn.execute(
            "INSERT INTO carbon_data (ts, supplier_id, payload_json, data_hash, anomaly_score, status)"
            " VALUES (?,?,?,?,?,?)",
            (time.time(), supplier_id, json.dumps(payload, ensure_ascii=False), data_hash, anomaly_score, status))
        conn.commit()
